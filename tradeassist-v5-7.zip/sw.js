const CACHE='ta-v5-1';
const ASSETS=[
  './','./index.html','./styles.css','./app.js',
  './modules/indicators.js','./modules/storage.js','./modules/risk.js',
  './modules/alphaVantage.js','./modules/news.js','./modules/trends.js',
  './modules/reco.js','./modules/portfolio.js','./modules/calendar.js',
  './modules/alloc.js','./modules/markets.js','./modules/budget.js',
  './modules/backtest.js','./modules/sim.js','./modules/config.js',
  './modules/net.js','./modules/vol.js','./manifest.webmanifest'
];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))))});
self.addEventListener('fetch',e=>{
  const req=e.request;
  const url=new URL(req.url);
  if(url.origin===location.origin){
    e.respondWith(caches.match(req).then(hit=>hit||fetch(req)));
    return;
  }
  // Network-first for APIs, fallback cache
  e.respondWith(fetch(req).then(r=>{
    const rc=r.clone();
    caches.open(CACHE).then(c=>c.put(req,rc));
    return r;
  }).catch(()=>caches.match(req)));
});

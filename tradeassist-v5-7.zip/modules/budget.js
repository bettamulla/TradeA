
import { DEFAULT_COINS, DEFAULT_FX, cryptoDaily, fxDaily } from './markets.js';
import { sma, atr } from './indicators.js';
import { signalState } from './reco.js';

function rrScore(entry, stop, target){
  const risk = Math.max(1e-9, entry - stop);
  const reward = Math.max(0, target - entry);
  const rr = reward / risk; // higher is better
  return Math.max(0, Math.min(5, rr)); // cap
}

function buildPlan(series, budget, riskPct){
  // series: ascending [{t,o,h,l,c}..]
  const closes = series.map(d=>d.c);
  const highs = series.map(d=>d.h);
  const lows = series.map(d=>d.l);
  const atr14 = atr(highs, lows, closes, 14);
  const i = closes.length - 1;
  const price = closes[i];
  const stop = price - (atr14[i]||0)*1.5;
  const target = price + (price - stop)*2; // 2R
  const riskCash = budget * (riskPct/100);
  const size = Math.max(0, Math.floor(riskCash / Math.max(1e-9, price - stop)));
  const score = rrScore(price, stop, target);
  return { price, stop, target, size, score };
}

export async function screenBudget(universe, budget, riskPct){
  const out = [];
  const coins = (universe==='crypto'||universe==='both') ? DEFAULT_COINS : [];
  const fx = (universe==='fx'||universe==='both') ? DEFAULT_FX : [];
  for(const c of coins){
    try{
      const data = await cryptoDaily(c);
      if(data.length<60) continue;
      const plan = buildPlan(data, budget, riskPct);
      const st = await import('./trends.js').then(()=>({}));
      // quick momentum proxy
      const momQ = data.length>63 ? (data.at(-1).c / data.at(-63).c - 1) : 0;
      const side = momQ>0 ? 'bullish' : 'bearish';
      out.push({ sym: c+'USD', market: 'crypto', ...plan, side, momQ });
    }catch{}
  }
  for(const p of fx){
    try{
      const data = await fxDaily(p);
      if(data.length<120) continue;
      const plan = buildPlan(data, budget, riskPct);
      const momQ = data.length>63 ? (data.at(-1).c / data.at(-63).c - 1) : 0;
      const side = momQ>0 ? 'bullish' : 'bearish';
      out.push({ sym: p, market: 'fx', ...plan, side, momQ });
    }catch{}
  }
  // Filter: require at least 1 unit affordable or FX always size>=1 micro-lot proxy
  const filt = out.filter(x=> x.size>=1 );
  // Rank by rr score and positive momentum
  filt.sort((a,b)=> (b.score + Math.max(0,b.momQ)) - (a.score + Math.max(0,a.momQ)) );
  return filt.slice(0,12);
}


// Simple risk-parity style allocation across recommendations using inverse volatility and de-correlation.
// Fetches recent returns via Alpha Vantage data already loaded by reco step.
export async function allocatePortfolio(symbols, key, budget){
  const lookback = 60; // trading days
  async function series(sym){
    const mod = await import('./alphaVantage.js');
    const rows = await mod.avDaily(sym, key, lookback+1);
    const closes = rows.map(r=>r.c);
    const rets = [];
    for(let i=1;i<closes.length;i++) rets.push((closes[i]/closes[i-1]-1));
    return rets;
  }
  const data = {};
  for(const s of symbols){ try{ data[s] = await series(s); }catch{ data[s]=null; } }
  const vols = {}; const validSyms = [];
  for(const [s,rets] of Object.entries(data)){
    if(rets && rets.length>10){
      const mean = rets.reduce((a,b)=>a+b,0)/rets.length;
      const varr = rets.reduce((a,b)=> a+(b-mean)*(b-mean), 0)/rets.length;
      vols[s] = Math.sqrt(varr)+1e-6;
      validSyms.push(s);
    }
  }
  if(validSyms.length===0) return [];
  // Inverse vol weights
  const inv = validSyms.map(s=> 1/vols[s]);
  const invSum = inv.reduce((a,b)=>a+b,0);
  const baseW = validSyms.map((s,i)=> inv[i]/invSum);
  // Convert to position sizes with round lot of 1 share
  const sizes = [];
  // Need latest prices. We rely on reco producing price map separately. Fallback to equal sizes.
  for(let i=0;i<validSyms.length;i++){
    sizes.push({ sym: validSyms[i], weight: baseW[i] });
  }
  // Scale weights to budget
  return sizes.map(x=> ({ ...x, capital: x.weight * budget }));
}

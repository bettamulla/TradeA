
// Quick expectancy using a naive momentum swing: enter if price > SMA(20), exit at 2R target or 1R stop.
import { sma, atr } from './indicators.js';

export function quickExpectancy(rows){
  // rows ascending [{o,h,l,c}]
  if(!rows || rows.length<80) return {win:0.5, exp:0.1};
  const c = rows.map(r=>r.c), h=rows.map(r=>r.h), l=rows.map(r=>r.l);
  const s20 = sma(c,20);
  const trAtr = atr(h,l,c,14);
  let wins=0, losses=0, exp=0, trades=0;
  for(let i=30;i<c.length-2;i++){
    if(s20[i]==null||trAtr[i]==null) continue;
    const price=c[i];
    const stop=price - 1.5*trAtr[i];
    const risk = price - stop;
    if(risk<=0) continue;
    if(c[i]>s20[i]){ // long bias
      trades++;
      // Proxy outcome using forward return next 10 bars
      const j=Math.min(i+10,c.length-1);
      const ret = (c[j]-price);
      if(ret >= 2*risk){ wins++; exp += 2; }
      else if(ret <= -1*risk){ losses++; exp -= 1; }
      else { // partial credit
        const r = ret/risk;
        if(r>0){ wins++; exp += Math.min(2,r); } else { losses++; exp += Math.max(-1,r); }
      }
    }
  }
  const total = Math.max(1, wins+losses);
  return { win: wins/total, exp: exp/Math.max(1,trades) };
}

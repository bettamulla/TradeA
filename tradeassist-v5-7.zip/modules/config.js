
export const CONFIG = {
  alphaRate: { max: 5, perMs: 60*1000 },   // 5/min
  finnhubRate: { max: 30, perMs: 60*1000 },// 30/min approximate
  defaultRefreshMin: 5,
  currency: 'GBP',
  locale: 'en-GB'
};
export const fmt = {
  num: (x, d=2)=> isFinite(x)? Number(x).toFixed(d): '—',
  pct: (x, d=1)=> isFinite(x)? (x*100).toFixed(d)+'%':'—',
  money: (x)=> isFinite(x)? new Intl.NumberFormat('en-GB',{style:'currency',currency:'GBP'}).format(x): '—',
  date: (iso)=> iso? new Date(iso).toLocaleString('en-GB'):'—'
};

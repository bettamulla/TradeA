
export function riskOfRuinSim(winRate=0.5, payoff=1.5, riskFrac=0.01, trials=5000, steps=200){
  let ruin=0;
  for(let t=0;t<trials;t++){
    let eq=1;
    for(let s=0;s<steps;s++){
      const win = Math.random()<winRate;
      const r = riskFrac;
      eq *= (1 + (win? payoff*r : -r));
      if(eq<=0.5){ ruin++; break; } // ruin threshold at -50%
    }
  }
  return ruin/trials;
}


import { getFH, getProxy } from './storage.js';

async function backedFetch(url){
  const proxy = getProxy();
  if(proxy){
    const u = new URL(proxy);
    u.searchParams.set('url', url);
    return fetch(u.toString());
  }
  return fetch(url);
}

export async function loadMacro(from,to){
  const fh = getFH(); if(!fh && !getProxy()) return [];
  const url = `https://finnhub.io/api/v1/calendar/economic?from=${from}&to=${to}&token=${fh||''}`;
  try{
    const { getJSON } = await import('./net.js'); const j = await getJSON(url);
    const list = j.economicCalendar || [];
    return list.slice(0,200).map(x=> ({
      date: x.time || x.date || '',
      country: x.country || '',
      event: x.event || x.indicator || x.title || 'Event',
      actual: x.actual || null,
      forecast: x.estimate || x.forecast || null,
      previous: x.previous || null,
      impact: x.impact || x.importance || ''
    }));
  }catch{ return []; }
}

export async function loadEarnings(from,to){
  const fh = getFH(); if(!fh && !getProxy()) return [];
  const url = `https://finnhub.io/api/v1/calendar/earnings?from=${from}&to=${to}&token=${fh||''}`;
  try{
    const { getJSON } = await import('./net.js'); const j = await getJSON(url);
    const list = j.earningsCalendar || [];
    return list.slice(0,200).map(x=> ({ date: x.date, symbol: x.symbol, hour: x.hour, estimate: x.epsEstimate, actual: x.epsActual }));
  }catch{ return []; }
}

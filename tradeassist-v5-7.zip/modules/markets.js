
import { getKey } from './storage.js';

export async function cryptoDaily(symbol){ // e.g., 'BTC', 'ETH'; assumes USD market
  const key = getKey(); if(!key) return [];
  const url = new URL('https://www.alphavantage.co/query');
  url.searchParams.set('function','DIGITAL_CURRENCY_DAILY');
  url.searchParams.set('symbol', symbol);
  url.searchParams.set('market','USD');
  url.searchParams.set('apikey', key);
  const res = await fetch(url);
  const j = await res.json();
  const ts = j['Time Series (Digital Currency Daily)'] || {};
  const rows = Object.entries(ts).map(([t,o])=>({ t, o:+o['1a. open (USD)'], h:+o['2a. high (USD)'], l:+o['3a. low (USD)'], c:+o['4a. close (USD)'], v:+o['5. volume'] })).sort((a,b)=> a.t.localeCompare(b.t));
  return rows.slice(-400);
}

export async function fxDaily(pair){ // 'EURUSD', 'GBPUSD', 'USDJPY'
  const key = getKey(); if(!key) return [];
  const url = new URL('https://www.alphavantage.co/query');
  url.searchParams.set('function','FX_DAILY');
  if(pair.length===6){
    url.searchParams.set('from_symbol', pair.slice(0,3));
    url.searchParams.set('to_symbol', pair.slice(3,6));
  }else{
    return [];
  }
  url.searchParams.set('outputsize','full');
  url.searchParams.set('apikey', key);
  const res = await fetch(url);
  const j = await res.json();
  const ts = j['Time Series FX (Daily)'] || {};
  const rows = Object.entries(ts).map(([t,o])=>({ t, o:+o['1. open'], h:+o['2. high'], l:+o['3. low'], c:+o['4. close'] })).sort((a,b)=> a.t.localeCompare(b.t));
  return rows.slice(-800);
}

export const DEFAULT_COINS = ['BTC','ETH','SOL','XRP','ADA','DOGE','LTC'];
export const DEFAULT_FX = ['EURUSD','GBPUSD','USDJPY','USDCHF','AUDUSD','USDCAD'];

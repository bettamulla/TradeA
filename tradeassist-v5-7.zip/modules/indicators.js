export function sma(arr, n){const out=new Array(arr.length).fill(null);let s=0;for(let i=0;i<arr.length;i++){s+=arr[i];if(i>=n)s-=arr[i-n];if(i>=n-1)out[i]=s/n}return out;}
export function ema(arr,n){const k=2/(n+1);const out=new Array(arr.length).fill(null);let p=arr[0];for(let i=0;i<arr.length;i++){p=k*arr[i]+(1-k)*(p||arr[i]);if(i>=n-1)out[i]=p}return out;}
export function rsi(c,p=14){const o=new Array(c.length).fill(null);let g=0,l=0;for(let i=1;i<=p;i++){const d=c[i]-c[i-1];if(d>=0)g+=d;else l-=d}let ag=g/p, al=l/p;for(let i=p+1;i<c.length;i++){const d=c[i]-c[i-1],G=Math.max(d,0),L=Math.max(-d,0);ag=(ag*(p-1)+G)/p;al=(al*(p-1)+L)/p;const rs=al===0?100:ag/al;o[i]=100-(100/(1+rs))}return o;}
export function macd(a, f=12, s=26, sig=9){const ef=ema(a,f), es=ema(a,s);const m=a.map((_,i)=>ef[i]!=null&&es[i]!=null?ef[i]-es[i]:null);const sg=ema(m.map(x=>x??0),sig);const h=m.map((mm,i)=>mm!=null&&sg[i]!=null?mm-sg[i]:null);return {macd:m, signal:sg, hist:h};}

export function atr(h,l,c,n=14){const tr=[null];for(let i=1;i<c.length;i++){const t=Math.max(h[i]-l[i], Math.abs(h[i]-c[i-1]), Math.abs(l[i]-c[i-1]));tr.push(t)}return ema(tr.map(x=>x??0), n)}


import { screenBudget } from './budget.js';
import { cryptoDaily, fxDaily, DEFAULT_COINS, DEFAULT_FX } from './markets.js';
import { quickExpectancy } from './backtest.js';

async function rowsFor(sym){
  if(sym.endsWith('USD') && sym.length<=6){ // crypto heuristic
    const coin = sym.replace('USD','');
    return await cryptoDaily(coin);
  }
  if(sym.length===6){ // FX
    return await fxDaily(sym);
  }
  return [];
}

export async function simulateGrowth(universe, startBudget, riskPct, steps){
  let budget = startBudget;
  const history = [];
  for(let k=0;k<steps;k++){
    const cands = await screenBudget(universe, budget, riskPct);
    if(cands.length===0) break;
    // take top candidate by current R/R score
    const pick = cands[0];
    // compute expectancy via quick backtest on its series
    const rows = await rowsFor(pick.sym);
    const qe = quickExpectancy(rows);
    const riskCash = budget * (riskPct/100);
    const expR = Math.max(-1, Math.min(2, qe.exp || 0.1)); // clamp to [-1,2] R
    const expProfit = expR * riskCash;
    const nextBudget = Math.max(0, budget + expProfit);
    history.push({ step:k+1, symbol: pick.sym, market: pick.market, side: pick.side, expR: +expR.toFixed(2), risk: +riskCash.toFixed(2), start: +budget.toFixed(2), end: +nextBudget.toFixed(2) });
    budget = nextBudget;
  }
  return { history, final: +budget.toFixed(2) };
}

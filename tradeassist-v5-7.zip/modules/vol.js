
// Volatility regime: use ATR% = ATR(14)/price
import { sma } from './indicators.js';
export function atrPctSeries(high,low,close,atrFn){
  const atr = atrFn(high,low,close,14);
  return atr.map((v,i)=> v!=null && close[i]? v/close[i] : null);
}
export function regimeFromAtrPct(atrPct){
  // thresholds tuned for equities daily
  if(atrPct==null) return 'unknown';
  if(atrPct < 0.015) return 'calm';
  if(atrPct < 0.03) return 'normal';
  return 'high';
}
